<?php
// Start the session to access form data
session_start();

// Check if form data exists
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Store form data in session variables
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['email'] = $_POST['email'];
    $_SESSION['datetime'] = $_POST['datetime'];
    $_SESSION['people'] = $_POST['people'];
    $_SESSION['message'] = $_POST['message'];
}

// Fetch session data
$name = $_SESSION['name'] ?? 'N/A';
$email = $_SESSION['email'] ?? 'N/A';
$datetime = $_SESSION['datetime'] ?? 'N/A';
$people = $_SESSION['people'] ?? 'N/A';
$message = $_SESSION['message'] ?? 'N/A';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Booking Invoice</h1>
        <div class="card">
            <div class="card-header bg-primary text-white">
                Booking Details
            </div>
            <div class="card-body">
                <p><strong>Name:</strong> <?php echo $name; ?></p>
                <p><strong>Email:</strong> <?php echo $email; ?></p>
                <p><strong>Date & Time:</strong> <?php echo $datetime; ?></p>
                <p><strong>Number of People:</strong> <?php echo $people; ?></p>
                <p><strong>Special Request:</strong> <?php echo $message; ?></p>
            </div>
        </div>
        <div class="text-center mt-4">
            <a href="booking.php" class="btn btn-primary">Back to Booking Menu</a>
        </div>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>