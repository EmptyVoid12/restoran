<?php
// Start the session to access booking data
session_start();

// Fetch session data for display
$name = $_SESSION['name'] ?? 'N/A';
$email = $_SESSION['email'] ?? 'N/A';
$datetime = $_SESSION['datetime'] ?? 'N/A';
$people = $_SESSION['people'] ?? 'N/A';
$message = $_SESSION['message'] ?? 'N/A';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Selection</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Select Payment Method</h1>
        <div class="card">
            <div class="card-header bg-primary text-white">
                Booking Summary
            </div>
            <div class="card-body">
                <p><strong>Name:</strong> <?php echo $name; ?></p>
                <p><strong>Email:</strong> <?php echo $email; ?></p>
                <p><strong>Date & Time:</strong> <?php echo $datetime; ?></p>
                <p><strong>Number of People:</strong> <?php echo $people; ?></p>
                <p><strong>Special Request:</strong> <?php echo $message; ?></p>
            </div>
        </div>

        <form action="process_payment.php" method="post" class="mt-4">
            <h3 class="mb-3">Choose Payment Method</h3>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="payment_method" id="creditCard" value="Credit Card" required>
                <label class="form-check-label" for="creditCard">
                    Credit Card
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="payment_method" id="paypal" value="PayPal">
                <label class="form-check-label" for="paypal">
                    PayPal
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="payment_method" id="bankTransfer" value="Bank Transfer">
                <label class="form-check-label" for="bankTransfer">
                    Bank Transfer
                </label>
            </div>

            <button type="submit" class="btn btn-primary mt-3">Proceed to Payment</button>
        </form>
        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-secondary">Back to Home</a>
        </div>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>